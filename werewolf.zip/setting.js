const config = require('./config.js');
const fs = require('fs');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'updateConfig',
    description: 'Update any configuration setting.',
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ **You do not have permission to change the configuration.**');
        }

        const [setting, value] = args;

        // Check if the setting exists in the config
        if (!config.hasOwnProperty(setting)) {
            return message.reply('⚠️ **This setting does not exist.**');
        }

        // Validate and parse value based on the type of setting
        let newValue;
        if (typeof config[setting] === 'number') {
            newValue = Number(value);
            if (isNaN(newValue)) {
                return message.reply(`❌ **Invalid input. ${setting} requires a number.**`);
            }
        } else {
            newValue = value; // For string settings like `token` or `allowedRoleId`
        }

        // Update and save config
        config[setting] = newValue;
        fs.writeFileSync('./config.js', `module.exports = ${JSON.stringify(config, null, 4)};`, 'utf8');

        // Send confirmation embed
        const embed = new EmbedBuilder()
            .setTitle('✅ Configuration Updated')
            .setDescription(`**Setting:** ${setting}\n**New Value:** ${newValue}`)
            .setColor('#00FF00')
            .setTimestamp();

        await message.channel.send({ embeds: [embed] });
    }
};
