module.exports = {
    "token": "",
    "startTime": 30000,
    "mafiaKillTime": 10000,
    "docActionTime": 20000,
    "detectorPhaseTime": 15000,
    "citizenVoteTime": 20000,
    "bodyguardPhaseTime": 15000,
    "allowedRoleIds": [
        "ROLE_ID_1",
        "1284504758765355109"
    ],
    "maxPlayers": 20,
    "minPlayers": 6
};